"""
The :mod: impyute.deletions module implements deletion algorithms
"""

from .complete_case import complete_case

__all__ = ["complete_case"]
