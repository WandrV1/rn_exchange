"""impyute.diagnostics.compare.py"""


class Tester:
    """Automates testing of datasets, machine learning models and imputation
    algorithms"""
    def __init__(self):
        """ Initializes the Tester object

        """
        pass

    def add(self, key, value):
        pass

    def _load_datasets(self, name):
        pass

    def run(self):
        pass
