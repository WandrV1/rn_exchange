def manipulate_config(config):
    return config
