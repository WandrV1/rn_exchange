from typing import Dict, Union

FEAT_TYPE_TYPE = Dict[Union[str, int], str]
