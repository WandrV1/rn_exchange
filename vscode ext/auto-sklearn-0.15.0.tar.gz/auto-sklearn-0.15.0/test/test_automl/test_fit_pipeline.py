"""Test specific ways of calling `fit_pipeline`"""
