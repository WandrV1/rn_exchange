"""Test predictions of an automl instance"""
